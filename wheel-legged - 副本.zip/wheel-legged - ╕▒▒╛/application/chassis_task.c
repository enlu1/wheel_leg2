#include "Chassis_task.h"

extern BalanceInfantry balance_infantry;
extern MF9025Instance *RightMotor, *LeftMotor;
extern int a;
void chassis_task(void const *pvParameters)
{
	vTaskDelay(500);
	BanlanceInfantry_init(&balance_infantry);
	while(1)
	{
//		accel_odom_fusion(&balance_infantry);
		get_sensor_message(&balance_infantry);
		
		leg_control(&balance_infantry);
//		InvMotionSolve(&balance_infantry,0.055,leg);
		MotionSolve(&balance_infantry);
		getTheta(&balance_infantry);
		updataK(&balance_infantry);
		LQR_Solve(&balance_infantry);
		roll_control(&balance_infantry);
//		get_leg_speed(&balance_infantry);
		VMC_Solve(&balance_infantry);
		jump(&balance_infantry);
		off_ground_detect(&balance_infantry);
		motor_output(&balance_infantry);
		ChassisModeSet(&balance_infantry);
		ChassisDataSet(&balance_infantry);
		if(balance_infantry.ChassisMode == CHASSIS_ZERO_FORCE)
		{
			balance_infantry.output_current_l = 0;
			balance_infantry.output_current_r = 0;
		}
//		if(balance_infantry.ChassisMode != CHASSIS_ZERO_FORCE)
//		{
//			a++;
//			if(a > 500)
//			{
//				a=0;
//				flag++;
//			}
//		}
		MF9025DataSet(LeftMotor,balance_infantry.output_current_l);//��ʱ��
		MF9025DataSet(RightMotor,balance_infantry.output_current_r);//��ǰ
		MF9025ControlLoop();

		vTaskDelay(2);
	}
}
