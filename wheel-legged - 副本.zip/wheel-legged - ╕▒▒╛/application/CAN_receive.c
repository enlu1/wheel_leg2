/**
  ****************************(C) COPYRIGHT 2019 DJI****************************
  * @file       can_receive.c/h
  * @brief      there is CAN interrupt function  to receive motor data,
  *             and CAN send function to send motor current to control motor.
  *             ������CAN�жϽ��պ��������յ������,CAN���ͺ������͵���������Ƶ��.
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. done
  *  V1.1.0     Nov-11-2019     RM              1. support hal lib
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 DJI****************************
  */

#include "CAN_receive.h"

#include "cmsis_os.h"

#include "main.h"

extern CAN_HandleTypeDef hcan1;
extern CAN_HandleTypeDef hcan2;
//motor data read
#define get_motor_measure(ptr, data)                                    \
    {                                                                   \
        (ptr)->last_ecd = (ptr)->ecd;                                   \
        (ptr)->ecd = (uint16_t)((data)[0] << 8 | (data)[1]);            \
        (ptr)->speed_rpm = (uint16_t)((data)[2] << 8 | (data)[3]);      \
        (ptr)->given_current = (uint16_t)((data)[4] << 8 | (data)[5]);  \
        (ptr)->temperate = (data)[6];                                   \
    }
/*
motor data,  0:chassis motor1 3508;1:chassis motor3 3508;2:chassis motor3 3508;3:chassis motor4 3508;
4:yaw gimbal motor 6020;5:pitch gimbal motor 6020;6:trigger motor 2006;
�������, 0:���̵��1 3508���,  1:���̵��2 3508���,2:���̵��3 3508���,3:���̵��4 3508���;
4:yaw��̨��� 6020���; 5:pitch��̨��� 6020���; 6:������� 2006���*/
static uint8_t gimbal_can_msend_data[8]; // Ħ��������
	
static CAN_TxHeaderTypeDef  gimbal_tx_message;
static uint8_t              gimbal_can_send_data[8];
static CAN_TxHeaderTypeDef  chassis_tx_message;
static uint8_t              chassis_can_send_data[8];
static CAN_TxHeaderTypeDef  c_tx_message;
static uint8_t              c_can_send_data[8];
static uint8_t 				gimbal_can_msend_data[8];
extern Joint_Motor_t DM8009_right;
extern Joint_Motor_t DM8009_left;

/**
  * @brief          hal CAN fifo call back, receive motor data
  * @param[in]      hcan, the point to CAN handle
  * @retval         none
  */
/**
  * @brief          hal��CAN�ص�����,���յ������
  * @param[in]      hcan:CAN���ָ��
  * @retval         none
  */
// void HAL_CAN_RxFifo1MsgPendingCallback(CAN_HandleTypeDef *hcan)
// {
//     CAN_RxHeaderTypeDef rx_header;
//     uint8_t rx_data[8];

//     HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO1, &rx_header, rx_data);

//     switch (rx_header.StdId)
//     {
//		case 0x0:
//		{
//					dm4310_fbdata(&DM8009_left, rx_data, 8);
//					break;
//		}
////		case 0x2:
////		{
////					dm4310_fbdata(&DM8009_right, rx_data, 8);
////					break;
////		}
////         default:
////         {
////             break;
////         }
//     }
// }



/**
  * @brief          send control current of motor (0x205, 0x206, 0x207, 0x208)
  * @param[in]      yaw: (0x205) 6020 motor control current, range [-30000,30000] 
  * @param[in]      pitch: (0x206) 6020 motor control current, range [-30000,30000]
  * @param[in]      shoot: (0x207) 2006 motor control current, range [-10000,10000]
  * @param[in]      rev: (0x208) reserve motor control current
  * @retval         none
  */
/**
  * @brief          ���͵�����Ƶ���(0x205,0x206,0x207,0x208)
  * @param[in]      yaw: (0x205) 6020������Ƶ���, ��Χ [-30000,30000]
  * @param[in]      pitch: (0x206) 6020������Ƶ���, ��Χ [-30000,30000]
  * @param[in]      shoot: (0x207) 2006������Ƶ���, ��Χ [-10000,10000]
  * @param[in]      rev: (0x208) ������������Ƶ���
  * @retval         none
  */
void CAN_cmd_gimbal(int16_t yaw, int16_t pitch, int16_t shoot, int16_t rev)
{
    uint32_t send_mail_box;
    gimbal_tx_message.StdId = CAN_GIMBAL_ALL_ID;
    gimbal_tx_message.IDE = CAN_ID_STD;
    gimbal_tx_message.RTR = CAN_RTR_DATA;
    gimbal_tx_message.DLC = 0x08;
    gimbal_can_send_data[0] = (yaw >> 8);
    gimbal_can_send_data[1] = yaw;
    gimbal_can_send_data[2] = (pitch >> 8);
    gimbal_can_send_data[3] = pitch;
    gimbal_can_send_data[4] = (shoot >> 8);
    gimbal_can_send_data[5] = shoot;
    gimbal_can_send_data[6] = (rev >> 8);
    gimbal_can_send_data[7] = rev;
    HAL_CAN_AddTxMessage(&GIMBAL_CAN, &gimbal_tx_message, gimbal_can_send_data, &send_mail_box);
}

/**
  * @brief          send control current of motor (0x205, 0x206, 0x207, 0x208)
  * @param[in]      yaw: (0x205) 6020 motor control current, range [-30000,30000] 
  * @param[in]      pitch: (0x206) 6020 motor control current, range [-30000,30000]
  * @param[in]      shoot: (0x207) 2006 motor control current, range [-10000,10000]
  * @param[in]      rev: (0x208) reserve motor control current
  * @retval         none
  */
/**
  * @brief          ���͵�����Ƶ���(0x203,0x204,0x207,0x208)
  * @param[in]      left_slider: (0x203) 2006������Ƶ���, ��Χ [-10000,10000]
  * @param[in]      right_slider: (0x204) 2006������Ƶ���, ��Χ [-10000,10000]
  * @retval         none
  */
void CAN_cmd_c(float target_vx, float target_w, uint8_t mode)
{
	static uint16_t vx,w;
	vx = (uint16_t)(target_vx * 10000);
	w = (uint16_t)(target_w * 10000);
    uint32_t send_mail_box;
    c_tx_message.StdId = 0x205;
    c_tx_message.IDE = CAN_ID_STD;
    c_tx_message.RTR = CAN_RTR_DATA;
    c_tx_message.DLC = 0x08;
    c_can_send_data[0] = (vx >> 8);
    c_can_send_data[1] = vx;
    c_can_send_data[2] = (w >> 8);
    c_can_send_data[3] = w;
    c_can_send_data[4] = mode;
    c_can_send_data[5] = 0;
    c_can_send_data[6] = 0;
    c_can_send_data[7] = 0;
    HAL_CAN_AddTxMessage(&hcan1, &c_tx_message, c_can_send_data, &send_mail_box);
}

/**
  * @brief          send CAN packet of ID 0x700, it will set chassis motor 3508 to quick ID setting
  * @param[in]      none
  * @retval         none
  */
/**
  * @brief          ����IDΪ0x700��CAN��,��������3508��������������ID
  * @param[in]      none
  * @retval         none
  */
void CAN_cmd_chassis_reset_ID(void)
{
    uint32_t send_mail_box;
    chassis_tx_message.StdId = 0x700;
    chassis_tx_message.IDE = CAN_ID_STD;
    chassis_tx_message.RTR = CAN_RTR_DATA;
    chassis_tx_message.DLC = 0x08;
    chassis_can_send_data[0] = 0;
    chassis_can_send_data[1] = 0;
    chassis_can_send_data[2] = 0;
    chassis_can_send_data[3] = 0;
    chassis_can_send_data[4] = 0;
    chassis_can_send_data[5] = 0;
    chassis_can_send_data[6] = 0;
    chassis_can_send_data[7] = 0;

    HAL_CAN_AddTxMessage(&CHASSIS_CAN, &chassis_tx_message, chassis_can_send_data, &send_mail_box);
}

/**
 * @brief          send control current of motor (0x201, 0x202, 0x203, 0x204)
 * @param[in]      mmotor1: (0x201) 3508 motor control current, range [-16384,16384]
 * @param[in]      mmotor2: (0x202) 3508 motor control current, range [-16384,16384]
 * @param[in]
 * @param[in]      rev: (0x208) reserve motor control current
 * @retval         none
 */
/**
 * @brief          ���͵�����Ƶ���(0x205,0x206,0x207,0x208)
 * @param[in]      fw1: (0x201) 3508������Ƶ���, ��Χ [-16384,16384]
 * @param[in]      fw2: (0x202) 3508������Ƶ���, ��Χ [-16384,16384]
 * @param[in]
 * @param[in]      rev: (0x208) ������������Ƶ���
 * @retval         none
 */
void CAN_cmd_friction(int16_t fw1, int16_t fw2, int16_t shoot, int16_t rev)
{
  uint32_t send_mail_box;
  gimbal_tx_message.StdId = 0x200;
  gimbal_tx_message.IDE = CAN_ID_STD;
  gimbal_tx_message.RTR = CAN_RTR_DATA;
  gimbal_tx_message.DLC = 0x08;
  gimbal_can_msend_data[0] = (fw1 >> 8);
  gimbal_can_msend_data[1] = fw1;
  gimbal_can_msend_data[2] = (fw2 >> 8);
  gimbal_can_msend_data[3] = fw2;
  gimbal_can_msend_data[4] = 0;
  gimbal_can_msend_data[5] = 0;
  gimbal_can_msend_data[6] = 0;
  gimbal_can_msend_data[7] = 0;
  HAL_CAN_AddTxMessage(&GIMBAL_CAN, &gimbal_tx_message, gimbal_can_msend_data, &send_mail_box);
}
//������ת�ֽ�
void FloatToByte(float floatNum, uint8_t *byteArry)
{
  uint8_t *pchar = (uint8_t *)&floatNum;
  for (int i = 0; i < sizeof(float); i++)
  {
    byteArry[3 - i] = *pchar;
    pchar++;
  }
}

///**
//  * @brief          return the yaw 6020 motor data point
//  * @param[in]      none
//  * @retval         motor data point
//  */
///**
//  * @brief          ����yaw 6020�������ָ��
//  * @param[in]      none
//  * @retval         �������ָ��
//  */
//const motor_measure_t *get_yaw_gimbal_motor_measure_point(void)
//{
//    return &motor_chassis[4];
//}

///**
//  * @brief          return the pitch 6020 motor data point
//  * @param[in]      none
//  * @retval         motor data point
//  */
///**
//  * @brief          ����pitch 6020�������ָ��
//  * @param[in]      none
//  * @retval         �������ָ��
//  */
//const motor_measure_t *get_pitch_gimbal_motor_measure_point(void)
//{
//    return &motor_chassis[5];
//}


///**
//  * @brief          return the trigger 2006 motor data point
//  * @param[in]      none
//  * @retval         motor data point
//  */
///**
//  * @brief          ���ز������ 2006�������ָ��
//  * @param[in]      none
//  * @retval         �������ָ��
//  */
//const motor_measure_t *get_trigger_motor_measure_point(void)
//{
//    return &motor_chassis[6];
//}


///**
//  * @brief          return the chassis 3508 motor data point
//  * @param[in]      i: motor number,range [0,3]
//  * @retval         motor data point
//  */
///**
//  * @brief          ���ص��̵�� 3508�������ָ��
//  * @param[in]      i: ������,��Χ[0,3]
//  * @retval         �������ָ��
//  */
//const motor_measure_t *get_chassis_motor_measure_point(uint8_t i)
//{
//    return &motor_chassis[(i & 0x03)];
//}
