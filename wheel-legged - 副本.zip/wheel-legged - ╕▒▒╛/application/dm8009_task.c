#include "dm8009_task.h"
int a=0;
extern BalanceInfantry balance_infantry;
extern MF9025Instance *RightMotor, *LeftMotor;
void dm8009_task(void const *pvParameters)
{
	vTaskDelay(500);
	while(1)
	{
//		balance_infantry.output_torque_l[1] = balance_infantry.J_l[0][0] * balance_infantry.virtual_torque_l[1] + balance_infantry.J_l[0][1] * balance_infantry.virtual_torque_l[2];
//		if(balance_infantry.ChassisMode == CHASSIS_ZERO_FORCE)
//		{
//			balance_infantry.output_torque_l[1] = 0;
//		}
		enable_motor_mode(&hcan1,balance_infantry.DM8009_Motor[0].para.id,MIT_MODE);
		
		vTaskDelay(1);
//		balance_infantry.output_torque_l[2] = balance_infantry.J_l[1][0] * balance_infantry.virtual_torque_l[1] + balance_infantry.J_l[1][1] * balance_infantry.virtual_torque_l[2];
//		if(balance_infantry.ChassisMode == CHASSIS_ZERO_FORCE)
//		{
//			balance_infantry.output_torque_l[2] = 0;
//		}
		enable_motor_mode(&hcan1,balance_infantry.DM8009_Motor[1].para.id,MIT_MODE);
		
		vTaskDelay(1);
//		balance_infantry.output_torque_r[2] = balance_infantry.J_r[1][0] * balance_infantry.virtual_torque_r[1] + balance_infantry.J_r[1][1] * balance_infantry.virtual_torque_r[2];
//		if(balance_infantry.ChassisMode == CHASSIS_ZERO_FORCE)
//		{
//			balance_infantry.output_torque_r[2] = 0;
//		}
		enable_motor_mode(&hcan2,balance_infantry.DM8009_Motor[2].para.id,MIT_MODE);
		
		vTaskDelay(1);
//		balance_infantry.output_torque_r[1] = balance_infantry.J_r[0][0] * balance_infantry.virtual_torque_r[1] + balance_infantry.J_r[0][1] * balance_infantry.virtual_torque_r[2];
//		if(balance_infantry.ChassisMode == CHASSIS_ZERO_FORCE)
//		{
//			balance_infantry.output_torque_r[1] = 0;
//		}
		enable_motor_mode(&hcan2,balance_infantry.DM8009_Motor[3].para.id,MIT_MODE);
		if(balance_infantry.ChassisMode == CHASSIS_ZERO_FORCE)
		{
			balance_infantry.output_torque_l[1] = 0;
			balance_infantry.output_torque_l[2] = 0;
			balance_infantry.output_torque_r[1] = 0;
			balance_infantry.output_torque_r[2] = 0;
		}
		mit_ctrl(&hcan1,balance_infantry.DM8009_Motor[0].para.id,0,0,0,0,-balance_infantry.output_torque_l[1]);
		mit_ctrl(&hcan1,balance_infantry.DM8009_Motor[1].para.id,0,0,0,0,-balance_infantry.output_torque_l[2]);
		mit_ctrl(&hcan2,balance_infantry.DM8009_Motor[2].para.id,0,0,0,0,balance_infantry.output_torque_r[2]);
		mit_ctrl(&hcan2,balance_infantry.DM8009_Motor[3].para.id,0,0,0,0,balance_infantry.output_torque_r[1]);
		vTaskDelay(1);
	}
}
