#ifndef OBSERVE_TASK_H
#define OBSERVE_TASK_H

#include "struct_typedef.h"
#include "ins_task.h"
#include "ChassisControl.h"

void xvEstimateKF_Init(KalmanFilter_t *EstimateKF);

#endif
