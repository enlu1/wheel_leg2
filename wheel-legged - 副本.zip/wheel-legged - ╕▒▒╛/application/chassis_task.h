/**
  ****************************(C) COPYRIGHT 2019 Ultra****************************
  * @file       chassis.c/h
  * @brief      chassis control task,
  *             ���̿�������
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-10-2024     Zhang Enlu        1. ��ʼ
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2019 Ultra****************************
  */
#ifndef CHASSIS_TASK_H
#define CHASSIS_TASK_H

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "dm4310_drv.h"
#include "bsp_can.h"
#include "struct_typedef.h"
#include "ChassisControl.h"

void chassis_task(void const *pvParameters);

#endif
