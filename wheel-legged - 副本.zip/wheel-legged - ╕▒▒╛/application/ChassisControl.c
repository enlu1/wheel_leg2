#include "ChassisControl.h"
/**
 * @brief ң������������
 *
 */
#define rc_deadband_limit(input, output, dealine)        \
	{                                                    \
		if ((input) > (dealine) || (input) < -(dealine)) \
		{                                                \
			(output) = (input);                          \
		}                                                \
		else                                             \
		{                                                \
			(output) = 0;                                \
		}                                                \
	}
BalanceInfantry balance_infantry;
// ������챵��ָ��
MF9025Instance *RightMotor, *LeftMotor;

/**
 * @brief        ƽ�ⲽ����ʼ��
 * @param    	 BalanceInfantry�ṹ��
 * @retval 	  none
 */
void BanlanceInfantry_init(BalanceInfantry *BalanceInfantry_init)
{

	/* ��ȡ������ָ�� */
//	BalanceInfantry_init->INS = &INS;
	BalanceInfantry_init->AccelData = get_accel_data_point();
	BalanceInfantry_init->GyroData = get_gyro_data_point();
	BalanceInfantry_init->Ins_Angle = get_INS_angle_point();
//	BalanceInfantry_init->Motion_Accel = get_motion_accel_data_point();
	
	BalanceInfantry_init->ChassisRC = get_remote_control_point();

	/* �����˸˳���ʼ�� */
	BalanceInfantry_init->L_left[1] = 0.15;
	BalanceInfantry_init->L_left[2] = 0.24;
	BalanceInfantry_init->L_left[3] = 0.24;
	BalanceInfantry_init->L_left[4] = 0.15;
	BalanceInfantry_init->L_left[5] = 0.11;

	BalanceInfantry_init->L_right[1] = 0.15;
	BalanceInfantry_init->L_right[2] = 0.24;
	BalanceInfantry_init->L_right[3] = 0.24;
	BalanceInfantry_init->L_right[4] = 0.15;
	BalanceInfantry_init->L_right[5] = 0.11;

	/* ���������K ???K11-K16�K21-K26 ??????????????? */
//	float K_params[12][4] = {
//		{-261.1788 , 276.4102 , -205.2317 , -0.2826},
//		{15.2730 , -20.6785 , -22.5742 , -0.0737},
//		{-417.9760 , 312.8020 , -80.3410 , -12.5746},
//		{-246.1633 , 190.1005 , -60.0347 , -10.6206},
//		{-1725.6168 , 1463.81502 , -463.7990 , 70.3188},
//		{-20.3831 , 22.8193 , -9.8840 , 3.7777},
//		{176.2893 , -76.6893 , -9.4289 , 17.5276},
//		{4.2716 , 2.6410 , -3.1581 , 2.7640},
//		{-1211.53212 , 1019.4551 , -316.7519 , 42.6278},
//		{-1058.484775 , 870.3273 , -262.5642 , 34.6019},
//		{3797.9323 , -2865.5022 , 748.3839 , 72.4304},
//		{151.2498 , -122.9012 , 36.4518 , 0.0066}
//	};
	float K_params[12][4] = {
		{-150.7597 , 181.1089 ,-102.0420 ,  -0.6813},
		{5.0434 ,  -2.9039 ,  -8.4391 ,  -0.1995},  
		{-39.2852 ,  38.4531 , -13.2748 ,  -1.1315},
		{-36.6292 ,  37.7980 , -14.7423 ,  -1.8098},
		{-17.5271  , 56.7711,  -40.4101 ,  11.1803},
		{ -0.3721  ,  5.3994  , -4.7069 ,   1.6541},
		{399.5220 ,-283.6943 ,  47.8815  ,  8.1444},
		{ 17.1405  , -8.2084  , -1.5404  ,  2.0749},
		{-4.4461  , 31.4938 , -24.2063  ,  6.3076},
		{-55.0282 ,  79.5346 , -41.2405  ,  9.0310},
		{397.9904 ,-380.9705 , 129.3614  ,  4.7323},
		{46.8289 , -46.8797 ,  16.9145   , 0.2595}
	};
	for (uint8_t i = 0; i < 12; i++)
	{
		for (uint8_t j = 0; j < 4; j++)
		{
			BalanceInfantry_init->K_coef[i][j] = K_params[i][j];
		}
	}
	/* �ȳ�pid��ʼ��(pid�����ڲ���) */
	const float leg_control_pid_l[3] = {250, 0, 0};
	const float leg_control_pid_r[3] = {250, 0, 0};
	const float leg_speed_pid_l[3] = {50,0,0};
	const float leg_speed_pid_r[3] = {50,0,0};
	const float roll_control_pid[3] = {100, 0, 0};
	const float leg_angle_control_pid_l[3] = {1.2, 0, 0};
	const float turn_pid[3] = {2.0, 0, 0};
	PID_init(&BalanceInfantry_init->turn_pid,PID_POSITION, turn_pid, 1.1, 0);
	PID_init(&BalanceInfantry_init->leg_speed_pid_l,PID_POSITION, leg_speed_pid_l, 15, 0);
	PID_init(&BalanceInfantry_init->leg_speed_pid_r,PID_POSITION, leg_speed_pid_r, 15, 0);
	PID_init(&BalanceInfantry_init->leg_angle_control_pid_l, PID_POSITION, leg_angle_control_pid_l, 1, 0);
	PID_init(&BalanceInfantry_init->leg_control_pid_l, PID_POSITION, leg_control_pid_l, 40, 0);
	PID_init(&BalanceInfantry_init->leg_control_pid_r, PID_POSITION, leg_control_pid_r, 40, 0);
	PID_init(&BalanceInfantry_init->roll_control_pid, PID_POSITION, roll_control_pid, 12, 0);
	/* ����9025��챵�� */
	MotorInitConfig_s MotorInitConfig =
		{
			.CanInitConfig.CanHandle = &hcan1,
			.ControllerParamInitConfig =
				{
					.AnglePid =
						{
							.Kp = 1.5f,
							.Ki = 0.0f,
							.Kd = 0.0f,
							.IntegralLimit = 1.3f,
							.Improve = PID_Trapezoid_Intergral | PID_Integral_Limit | PID_Derivative_On_Measurement,
							.MaxOut = 5.0f,
						},
					.SpeedPid =
						{
							.Kp = 0.0f,
							.Ki = 0.05f,
							.Kd = 0.0f,
							.IntegralLimit = 0.0f,
							.Improve = PID_Trapezoid_Intergral | PID_Integral_Limit | PID_Derivative_On_Measurement,
							.MaxOut = 1.0f,
						},
					.CurrentPid = // ���������õ�����pid��ת��pid
					{
						.Kp = 2.0f,
						.Ki = 0.0F,
						.Kd = 0.0f,
						.IntegralLimit = 0.0f,
						.Improve = PID_Trapezoid_Intergral | PID_Integral_Limit | PID_Derivative_On_Measurement,
						.MaxOut = 1.0f,
					}},
			.ControllerSettingInitConfig =
				{
					.AngleFeedbackSource = MOTOR_FEED,
					.SpeedFeedbackSource = MOTOR_FEED,
					.OuterLoopType = TORQUE_LOOP,
					.CloseLoopType = TORQUE_LOOP,
				},
			.MotorType = MF9025,
		};
	MotorInitConfig.CanInitConfig.TxID = 1;
	MotorInitConfig.ControllerSettingInitConfig.MotorReverseFlag = MOTOR_DIRECTION_NORMAL;
	LeftMotor = MF9025Init(&MotorInitConfig);
	MotorInitConfig.CanInitConfig.CanHandle = &hcan2;
	MotorInitConfig.CanInitConfig.TxID = 2;
	MotorInitConfig.ControllerSettingInitConfig.MotorReverseFlag = MOTOR_DIRECTION_REVERSE;
	RightMotor = MF9025Init(&MotorInitConfig);
	/* ��ʼ����ʹ��8009�ؽڵ�� */
	joint_motor_init(&balance_infantry.DM8009_Motor[0], 1, MIT_MODE);
	joint_motor_init(&balance_infantry.DM8009_Motor[1], 2, MIT_MODE);
	joint_motor_init(&balance_infantry.DM8009_Motor[2], 4, MIT_MODE);
	joint_motor_init(&balance_infantry.DM8009_Motor[3], 6, MIT_MODE);
	for (uint8_t i = 0; i < 2; i++)
	{
		for (uint8_t j = 0; j < 20; j++)
		{
			enable_motor_mode(&hcan1, balance_infantry.DM8009_Motor[i].para.id, MIT_MODE);
			vTaskDelay(2);
		}
	}
	for (uint8_t i = 2; i < 4; i++)
	{
		for (uint8_t j = 0; j < 10; j++)
		{
			enable_motor_mode(&hcan2, balance_infantry.DM8009_Motor[i].para.id, MIT_MODE);
			vTaskDelay(2);
		}
	}
	balance_infantry.target_L_left = 0.14;
	balance_infantry.target_L_right = 0.14;
	balance_infantry.jump_flag=0;
	/* �������˲���ʼ�� */
	KF_Wheel_Accel_Init(10, 10, 1000);
	BalanceInfantry_init->Wheel_Accel_Fusion = &Wheel_Accel_Fusion;

}

/**
 * @brief        ��ȡ��������Ϣ
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void get_sensor_message(BalanceInfantry *balance_infantry)
{
	/*
	theta,theta_dot,x,x_dot,phi,phi_dot
	1.������yaw���������
	2.�����뿨�����˲�֮�������(x,x_dot)
	*/
	float LVel, RVel, Vel,last_pitch;
	static uint16_t a=0;
	/* IMU���ݻ�ȡ */
//	balance_infantry->state_vector_l[4] = balance_infantry->INS->Pitch;
//	balance_infantry->state_vector_l[5] = balance_infantry->INS->Gyro[0];
//	rc_filter(&balance_infantry->state_vector_l[5],balance_infantry->INS->Gyro[0],0.002f,0.00199f);
//	balance_infantry->state_vector_r[4] = balance_infantry->INS->Pitch;
//	balance_infantry->state_vector_r[5] = balance_infantry->INS->Gyro[0];
//	rc_filter(&balance_infantry->state_vector_r[5],balance_infantry->INS->Gyro[0],0.002f,0.00199f);
	balance_infantry->state_vector_l[4] = -balance_infantry->Ins_Angle[1];
	balance_infantry->state_vector_l[5] = -balance_infantry->GyroData[1];
	balance_infantry->state_vector_r[4] = -balance_infantry->Ins_Angle[1];
	balance_infantry->state_vector_r[5] = -balance_infantry->GyroData[1];

//	balance_infantry->state_vector[4] = 0;
//	balance_infantry->state_vector[5] = 0;

	/* ��ȡx,x_dot */
	RVel = RightMotor->MF9025MotorMesure.RealSpeed;
	LVel = LeftMotor->MF9025MotorMesure.RealSpeed;
	// �ж�����ת���ٶ��÷����Ƿ���Ҫ���ڽ��պ����
	if (RightMotor->MotorSetting.MotorReverseFlag == MOTOR_DIRECTION_REVERSE)
	{
		RVel *= -1;
	}
	else if (LeftMotor->MotorSetting.MotorReverseFlag == MOTOR_DIRECTION_REVERSE)
	{
		LVel *= -1;
	}
	Vel = -(RVel + LVel) / 2.0f;
//	balance_infantry->state_vector_l[3] = Vel;
//	balance_infantry->state_vector_r[3] = Vel;
	
	
//	a++;
//	if(a == 1000)
//	{
//		a--;
////		balance_infantry->state_vector_l[3] = balance_infantry->Wheel_Accel_Fusion->x_v;
////		balance_infantry->state_vector_r[3] = balance_infantry->Wheel_Accel_Fusion->x_v;
//	}
//	balance_infantry->state_vector_l[2] = -(LeftMotor->MF9025MotorMesure.TotalAngle - RightMotor->MF9025MotorMesure.TotalAngle) / 360.0f * PI * WhellRadius;
//	balance_infantry->state_vector_r[2] = -(LeftMotor->MF9025MotorMesure.TotalAngle - RightMotor->MF9025MotorMesure.TotalAngle) / 360.0f * PI * WhellRadius;
	
//	balance_infantry->state_vector_l[2] = 0;
//	balance_infantry->state_vector_r[2] = 0;
	
//	if(balance_infantry->target_vector[3] == 0)
//	{
//		GetDeltaT(&balance_infantry->stop_time);
//		if(GetDeltaTtoNow(&balance_infantry->stop_time) > 2.0f)
//		{
//			if(GetDeltaTtoNow(&balance_infantry->stop_time) > 6.0f)
//			{
//				balance_infantry->state_vector_l[2] = -(LeftMotor->MF9025MotorMesure.TotalAngle - RightMotor->MF9025MotorMesure.TotalAngle) / 360.0f * PI * WhellRadius;
//				balance_infantry->state_vector_r[2] = -(LeftMotor->MF9025MotorMesure.TotalAngle - RightMotor->MF9025MotorMesure.TotalAngle) / 360.0f * PI * WhellRadius;
//			}
//			else
//			{
//			LeftMotor->MF9025MotorMesure.TotalAngle = 0;
//			RightMotor->MF9025MotorMesure.TotalAngle = 0;
//			}
//		}
//	}
//	else
//	{
//		balance_infantry->state_vector_l[2] = 0;
//		balance_infantry->state_vector_r[2] = 0;
//	}
	
	
//	if(balance_infantry->target_vector[3] != 0)
//	{
////	if(balance_infantry->ChassisMode != CHASSIS_ZERO_FORCE)
////	{
//		balance_infantry->state_vector_l[3] = balance_infantry->Wheel_Accel_Fusion->x_v;
//		balance_infantry->state_vector_r[3] = balance_infantry->Wheel_Accel_Fusion->x_v;
//	
//	}
	/* ������phi�ǻ�ȡ (?????phi1) */
	balance_infantry->phi_left[1] = balance_infantry->DM8009_Motor[LEFT_KNEE_RIGHT].para.pos + PI / 2 + 0.13f;
	balance_infantry->phi_left[4] = balance_infantry->DM8009_Motor[LEFT_KNEE_LEFT].para.pos + PI / 2 + 0.09f;
	balance_infantry->phi_right[1] = -balance_infantry->DM8009_Motor[RIGHT_KNEE_LEFT].para.pos + PI / 2 ;
	balance_infantry->phi_right[4] = -balance_infantry->DM8009_Motor[RIGHT_KNEE_RIGHT].para.pos + PI / 2 -0.10f;

	/* �ؽڵ���������� */
	for (uint8_t i = 0; i < 4; i++)
	{
		balance_infantry->sensors_info.torque_feed_back[i] = balance_infantry->DM8009_Motor[i].para.tor;
	}

	/* ������챵������  */
	balance_infantry->sensors_info.wheel_torque[0] = LeftMotor->MF9025MotorMesure.RealTorque;
	balance_infantry->sensors_info.wheel_torque[1] = RightMotor->MF9025MotorMesure.RealTorque;
	//�����ܹ�yaw��Ƕ�
	if (balance_infantry->Ins_Angle[0] -balance_infantry->yaw_last_angle > 3.1415926f)
	{
		balance_infantry->yaw_count--;
	}
	else if (balance_infantry->Ins_Angle[0] -balance_infantry->yaw_last_angle < -3.1415926f)
	{
		balance_infantry->yaw_count++;
	}
	balance_infantry->yaw_total_angle = 6.283f* balance_infantry->yaw_count + balance_infantry->Ins_Angle[0];
	balance_infantry->yaw_last_angle = balance_infantry->Ins_Angle[0];
}
/**
 * @brief        ����ģʽѡ��
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void ChassisModeSet(BalanceInfantry *balance_infantry)
{
	switch (balance_infantry->ChassisRC->rc.s[CHASSIS_MODE_CHANNEL])
	{
	case RC_SW_DOWN:
		balance_infantry->ChassisMode = CHASSIS_ZERO_FORCE;
		break;
	case RC_SW_MID:
		balance_infantry->ChassisMode = CHASSIS_NO_FOLLOW_YAW;
		break;
	case RC_SW_UP:
		balance_infantry->ChassisMode = CHASSIS_IKUN;
		break;
	default:
		balance_infantry->ChassisMode = CHASSIS_ZERO_FORCE;
		break;
	}
	balance_infantry->Last_ChassisMode = balance_infantry->ChassisMode;
}

/**
 * @brief        ����ң������ֵ�����ٶ�
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
float LeftSteerTorque,RightSteerTorque;
void ChassisDataSet(BalanceInfantry *balance_infantry)
{
	fp32 VxSetChannel;
	fp32 w_set;
	fp32 W_v;
	rc_deadband_limit(balance_infantry->ChassisRC->rc.ch[CHASSIS_X_CHANNEL], VxSetChannel, CHASSIS_RC_DEADLINE);
	// ���̿���
	if (balance_infantry->ChassisRC->key.v & CHASSIS_FRONT_KEY)
	{
		VxSetChannel = MAX_V_SPEED;
	}
	else if (balance_infantry->ChassisRC->key.v & CHASSIS_BACK_KEY)
	{
		VxSetChannel = -MAX_V_SPEED;
	}
	// û��ֱֵ�Ӹ���
	if (VxSetChannel < CHASSIS_RC_DEADLINE * CHASSIS_V_SEN && VxSetChannel > -CHASSIS_RC_DEADLINE * CHASSIS_V_SEN)
	{
		VxSetChannel = 0.0f;
	}
	VxSetChannel *= CHASSIS_V_SEN;
//	slope_following(&VxSetChannel,&balance_infantry->target_vector[3],0.05);
	balance_infantry->target_vector[3] = VxSetChannel;
	//�ٶ�Ϊ0 ��λ��
//	if(balance_infantry->last_target_vel != 0 && balance_infantry->target_vector[3] == 0)
//	{
//		LeftMotor->MF9025MotorMesure.TotalCir = 0;
//		RightMotor->MF9025MotorMesure.TotalCir = 0;
//		balance_infantry->target_vector[2] = balance_infantry->state_vector_l[2];
//	}
//	if(balance_infantry->target_vector[3] == 0)
//	{
//		balance_infantry->state_vector_l[2] = -(LeftMotor->MF9025MotorMesure.TotalAngle - RightMotor->MF9025MotorMesure.TotalAngle) / 360.0f * PI * WhellRadius;
//		balance_infantry->state_vector_r[2] = -(LeftMotor->MF9025MotorMesure.TotalAngle - RightMotor->MF9025MotorMesure.TotalAngle) / 360.0f * PI * WhellRadius;
//	}
//	else
//	{
//		balance_infantry->target_vector[2] = balance_infantry->state_vector_l[2];
//		balance_infantry->state_vector_l[2] = 0;
//		balance_infantry->state_vector_r[2] = 0;
//	}
	//��
	
	w_set = balance_infantry->ChassisRC->rc.ch[2] * 0.000757575757575f;
//	balance_infantry->target_L_left += balance_infantry->ChassisRC->rc.ch[0] * 0.00000015151515f;
//	balance_infantry->target_L_left = LIMIT_MAX_MIN(balance_infantry->target_L_left, 0.24f, 0.12f);
//	balance_infantry->target_L_right += balance_infantry->ChassisRC->rc.ch[3] * 0.00000015151515f;
//	balance_infantry->target_L_right = LIMIT_MAX_MIN(balance_infantry->target_L_right, 0.24f, 0.12f);
	W_v = w_set/0.25f;
	if(W_v != 0)
	{
		balance_infantry->LeftSteerTorque = PID_Calc(&LeftMotor->MF9025Controler.current_PID, LeftMotor->MF9025MotorMesure.RealSpeed , W_v);//+ (LeftMotor->MF9025MotorMesure.RealSpeed  - RightMotor->MF9025MotorMesure.RealSpeed)
		balance_infantry->RightSteerTorque = PID_Calc(&RightMotor->MF9025Controler.current_PID, RightMotor->MF9025MotorMesure.RealSpeed , -W_v);// - (LeftMotor->MF9025MotorMesure.RealSpeed - RightMotor->MF9025MotorMesure.RealSpeed)
	}
	else{
//		LeftSteerTorque = 0;
//		RightSteerTorque = 0;
	}
	if(balance_infantry->ChassisMode == CHASSIS_NO_FOLLOW_YAW)
	{
		balance_infantry->yaw_set += balance_infantry->ChassisRC->rc.ch[2] * -0.00000757575757575f;
	}
//	LeftSteerTorque = PID_calc(&balance_infantry->turn_pid,balance_infantry->GyroData[0],W_v);
//	RightSteerTorque = PID_calc(&balance_infantry->turn_pid,balance_infantry->GyroData[0],W_v);
//	balance_infantry->yaw_set = 0;
	LeftSteerTorque = PID_calc(&balance_infantry->turn_pid,balance_infantry->yaw_total_angle,balance_infantry->yaw_set)-TURN_KD*balance_infantry->GyroData[0];
	RightSteerTorque =  PID_calc(&balance_infantry->turn_pid,balance_infantry->yaw_total_angle,balance_infantry->yaw_set)-TURN_KD*balance_infantry->GyroData[0];


	if(balance_infantry->ChassisMode == CHASSIS_IKUN)
	{
//		balance_infantry->roll_set = balance_infantry->ChassisRC->rc.ch[2] * 0.0303030303030303f;
		balance_infantry->roll_set = balance_infantry->ChassisRC->rc.ch[2] * 0.00052666f;
		LeftSteerTorque = 0;
		RightSteerTorque = 0;
	}
	else
	{
		balance_infantry->roll_set = ROLL_ZERO;
	}
	if(balance_infantry->ChassisRC->rc.ch[4] == 660 && balance_infantry->ChassisMode == CHASSIS_NO_FOLLOW_YAW)
	{
		balance_infantry->jump_flag=1;
	}
}

/**
 * @brief        ??????
 * @param    	  BalanceInfantry???
 * @retval 	  none
 */
void set_target_vector(BalanceInfantry *balance_infantry)
{
	/* ���ٶȻ��ǿ�λ�ƴ����� */
	// theta,theta_dot,x,x_dot,phi,phi_dot
	ChassisModeSet(balance_infantry);
	ChassisDataSet(balance_infantry);
	switch (balance_infantry->ChassisMode)
	{
	case CHASSIS_NO_FOLLOW_YAW:
	case CHASSIS_IKUN:
		for (uint8_t i = 0; i < 10; i++)
		{
			for (uint8_t j = 0; j < 4; j++)
			{
				enable_motor_mode(&JOINT_HCAN, MIT_MODE, balance_infantry->DM8009_Motor[j].para.id);
			}
		}
		balance_infantry->target_vector[0] = 0.0f;
		//����ģ��ӦΪ0
		//balance_infantry->target_vector[0] = 0.0f;
		balance_infantry->target_vector[4] = -0.05f;
		balance_infantry->target_vector[5] = 0.0f;
		
		break;
	case CHASSIS_ZERO_FORCE:
		/* ʧ�ܹؽڵ������챵�� */
		for (uint8_t i = 0; i < 10; i++)
		{
			for (uint8_t j = 0; j < 4; j++)
			{
				enable_motor_mode(&JOINT_HCAN, MIT_MODE, balance_infantry->DM8009_Motor[j].para.id);
			}
		}
		RightMotor->MF9025StopFlag = MOTOR_STOP;
		LeftMotor->MF9025StopFlag = MOTOR_STOP;
		break;
	default:
		break;
	}
}
/**
 * @brief        ���˶�ѧ����
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void InvMotionSolve(BalanceInfantry *balance_infantry,float x_C,float y_C)
{
	float fai1_x1,fai1_x2, fai4,cosf12,f12,cosf1,cosf34,f34,A,B,C,ft;
	float x_c = x_C;
	float y_c = y_C;
	float l1 = 0.15, l2 = 0.24, l3 = 0.24, l4 = 0.15, l5 = 0.11;
	cosf12 = (x_c * x_c + y_c*y_c -l1*l1-l2*l2)/(2*l1*l2);
	f12 = 2*PI -  acos(cosf12);
	cosf1 = (l2*y_c*arm_sin_f32(f12)+x_c*(l2*arm_cos_f32(f12)+l1))/((l2*arm_cos_f32(f12)+l1)*(l2*arm_cos_f32(f12)+l1) + l2*l2*arm_sin_f32(f12)*arm_sin_f32(f12));
	fai1_x1 = acos(cosf1);
	cosf34 = ((x_c - l5)*(x_c - l5)+y_c*y_c-l3*l3-l4*l4)/(2*l3*l4);
	f34 = 2*PI - acos(cosf34);
	A = l5 - x_c;
	B = l3 * arm_sin_f32(f34);
	C = l4 + l3*arm_cos_f32(f34);
	ft = acos(B/sqrt(B*B+C*C));
	fai4 = PI - (ft - asin(A/sqrt(B*B+C*C)));
	balance_infantry->target_angle_left = -(PI/2 - fai4);
	balance_infantry->target_angle_right = (PI/2 - fai4);
}
/**
 * @brief        ���˶�ѧ����
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void MotionSolve(BalanceInfantry *balance_infantry)
{
	float B_D_distance_2, A0, C0, temp;
	float b0;

	/* �������˶�ѧ���� */
	balance_infantry->SolverLeft.x_B =
		balance_infantry->L_left[1] * arm_cos_f32(balance_infantry->phi_left[1]);
	balance_infantry->SolverLeft.y_B =
		balance_infantry->L_left[1] * arm_sin_f32(balance_infantry->phi_left[1]);
	balance_infantry->SolverLeft.x_D =
		balance_infantry->L_left[5] + balance_infantry->L_left[4] * arm_cos_f32(balance_infantry->phi_left[4]);
	balance_infantry->SolverLeft.y_D =
		balance_infantry->L_left[4] * arm_sin_f32(balance_infantry->phi_left[4]);
	B_D_distance_2 =
		(balance_infantry->SolverLeft.x_D - balance_infantry->SolverLeft.x_B) * (balance_infantry->SolverLeft.x_D - balance_infantry->SolverLeft.x_B) + (balance_infantry->SolverLeft.y_D - balance_infantry->SolverLeft.y_B) * (balance_infantry->SolverLeft.y_D - balance_infantry->SolverLeft.y_B);
	A0 = 2 * balance_infantry->L_left[2] * (balance_infantry->SolverLeft.x_D - balance_infantry->SolverLeft.x_B);
	b0 = 2 * balance_infantry->L_left[2] * (balance_infantry->SolverLeft.y_D - balance_infantry->SolverLeft.y_B);
	C0 = balance_infantry->L_left[2] * balance_infantry->L_left[2] + B_D_distance_2 - balance_infantry->L_left[3] * balance_infantry->L_left[3];
	temp = b0 + sqrt(A0 * A0 + b0 * b0 - C0 * C0);
	balance_infantry->phi_left[2] = 2 * arm_atan2_f32(temp, A0 + C0);

	balance_infantry->SolverLeft.x_C =
		balance_infantry->SolverLeft.x_B + balance_infantry->L_left[2] * arm_cos_f32(balance_infantry->phi_left[2]);
	balance_infantry->SolverLeft.y_C =
		balance_infantry->SolverLeft.y_B + balance_infantry->L_left[2] * arm_sin_f32(balance_infantry->phi_left[2]);
	balance_infantry->SolverLeft.x_C -=
		balance_infantry->L_left[5] / 2;

	balance_infantry->L_left[0] =
		sqrt(balance_infantry->SolverLeft.x_C * balance_infantry->SolverLeft.x_C + balance_infantry->SolverLeft.y_C * balance_infantry->SolverLeft.y_C);
	balance_infantry->phi_left[0] =
		arm_atan2_f32(balance_infantry->SolverLeft.y_C, balance_infantry->SolverLeft.x_C);
	balance_infantry->SolverLeft.x_C +=
		balance_infantry->L_left[5] / 2;
	balance_infantry->phi_left[3] = arm_atan2_f32(balance_infantry->SolverLeft.y_B - balance_infantry->SolverLeft.y_D + balance_infantry->L_left[2] * arm_sin_f32(balance_infantry->phi_left[2]),balance_infantry->SolverLeft.x_B - balance_infantry->SolverLeft.x_D + balance_infantry->L_left[2] * arm_cos_f32(balance_infantry->phi_left[2]));
//	balance_infantry->phi_left[3] = PI - arm_atan2_f32(balance_infantry->SolverLeft.y_C - balance_infantry->SolverLeft.y_D,balance_infantry->SolverLeft.x_D - balance_infantry->SolverLeft.x_B);

	/* �������˶�ѧ���� */
	balance_infantry->SolverRight.x_B =
		balance_infantry->L_right[1] * arm_cos_f32(balance_infantry->phi_right[1]);
	balance_infantry->SolverRight.y_B =
		balance_infantry->L_right[1] * arm_sin_f32(balance_infantry->phi_right[1]);
	balance_infantry->SolverRight.x_D =
		balance_infantry->L_right[5] + balance_infantry->L_right[4] * arm_cos_f32(balance_infantry->phi_right[4]);
	balance_infantry->SolverRight.y_D =
		balance_infantry->L_right[4] * arm_sin_f32(balance_infantry->phi_right[4]);
	B_D_distance_2 =
		(balance_infantry->SolverRight.x_D - balance_infantry->SolverRight.x_B) * (balance_infantry->SolverRight.x_D - balance_infantry->SolverRight.x_B) + (balance_infantry->SolverRight.y_D - balance_infantry->SolverRight.y_B) * (balance_infantry->SolverRight.y_D - balance_infantry->SolverRight.y_B);
	A0 = 2 * balance_infantry->L_right[2] * (balance_infantry->SolverRight.x_D - balance_infantry->SolverRight.x_B);
	b0 = 2 * balance_infantry->L_right[2] * (balance_infantry->SolverRight.y_D - balance_infantry->SolverRight.y_B);
	C0 = balance_infantry->L_right[2] * balance_infantry->L_right[2] + B_D_distance_2 - balance_infantry->L_right[3] * balance_infantry->L_right[3];
	temp = b0 + sqrt(A0 * A0 + b0 * b0 - C0 * C0);
	balance_infantry->phi_right[2] = 2 * arm_atan2_f32(temp, A0 + C0);

	balance_infantry->SolverRight.x_C =
		balance_infantry->SolverRight.x_B + balance_infantry->L_right[2] * arm_cos_f32(balance_infantry->phi_right[2]);
	balance_infantry->SolverRight.y_C =
		balance_infantry->SolverRight.y_B + balance_infantry->L_right[2] * arm_sin_f32(balance_infantry->phi_right[2]);
	balance_infantry->SolverRight.x_C -=
		balance_infantry->L_right[5] / 2;

	balance_infantry->L_right[0] =
		sqrt(balance_infantry->SolverRight.x_C * balance_infantry->SolverRight.x_C + balance_infantry->SolverRight.y_C * balance_infantry->SolverRight.y_C);
	balance_infantry->phi_right[0] =
		arm_atan2_f32(balance_infantry->SolverRight.y_C, balance_infantry->SolverRight.x_C);
	balance_infantry->SolverRight.x_C +=
		balance_infantry->L_right[5] / 2;
	balance_infantry->phi_right[3] = arm_atan2_f32(balance_infantry->SolverRight.y_B - balance_infantry->SolverRight.y_D + balance_infantry->L_right[2] * arm_sin_f32(balance_infantry->phi_right[2]),balance_infantry->SolverRight.x_B - balance_infantry->SolverRight.x_D + balance_infantry->L_right[2] * arm_cos_f32(balance_infantry->phi_right[2]));


	float sigma_1, sigma_2, sigma_3;

	/* ����sigma�� */
	sigma_1 = arm_sin_f32(balance_infantry->phi_left[3] - balance_infantry->phi_left[2]);
	sigma_2 = arm_sin_f32(balance_infantry->phi_left[3] - balance_infantry->phi_left[4]);
	sigma_3 = arm_sin_f32(balance_infantry->phi_left[1] - balance_infantry->phi_left[2]);

	/* �ſɱȾ���ļ��� */
	balance_infantry->J_l[0][0] =
		-balance_infantry->L_left[1] * arm_cos_f32(balance_infantry->phi_left[0] - balance_infantry->phi_left[3]) * sigma_3 / balance_infantry->L_left[0] / sigma_1;
	balance_infantry->J_l[0][1] =
		-balance_infantry->L_left[1] * arm_sin_f32(balance_infantry->phi_left[0] - balance_infantry->phi_left[3]) * sigma_3 / sigma_1;
	balance_infantry->J_l[1][0] =
		-balance_infantry->L_left[4] * arm_cos_f32(balance_infantry->phi_left[0] - balance_infantry->phi_left[2]) * sigma_2 / balance_infantry->L_left[0] / sigma_1;
	balance_infantry->J_l[1][1] =
		-balance_infantry->L_left[4] * arm_sin_f32(balance_infantry->phi_left[0] - balance_infantry->phi_left[2]) * sigma_2 / sigma_1;


	/* ���ȵ�VMC���� */
	sigma_1 = arm_sin_f32(balance_infantry->phi_right[3] - balance_infantry->phi_right[2]);
	sigma_2 = arm_sin_f32(balance_infantry->phi_right[3] - balance_infantry->phi_right[4]);
	sigma_3 = arm_sin_f32(balance_infantry->phi_right[1] - balance_infantry->phi_right[2]);

	/* �ſɱȾ���ļ��� */
	balance_infantry->J_r[0][0] =
		-balance_infantry->L_right[1] * arm_cos_f32(balance_infantry->phi_right[0] - balance_infantry->phi_right[3]) * sigma_3 / balance_infantry->L_right[0] / sigma_1;
	balance_infantry->J_r[0][1] =
		-balance_infantry->L_right[1] * arm_sin_f32(balance_infantry->phi_right[0] - balance_infantry->phi_right[3]) * sigma_3 / sigma_1;
	balance_infantry->J_r[1][0] =
		-balance_infantry->L_right[4] * arm_cos_f32(balance_infantry->phi_right[0] - balance_infantry->phi_right[2]) * sigma_2 / balance_infantry->L_right[0] / sigma_1;
	balance_infantry->J_r[1][1] =
		-balance_infantry->L_right[4] * arm_sin_f32(balance_infantry->phi_right[0] - balance_infantry->phi_right[2]) * sigma_2 / sigma_1;
}

/**
 * @brief        ��ȡ�Ȳ�thera��
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void getTheta(BalanceInfantry *balance_infantry)
{
	/* �����Ȳ�thera�� (���Ŵ�ȷ��)(?????????) */
	balance_infantry->theta_left = (PI/2 - balance_infantry->phi_left[0] - balance_infantry->state_vector_l[4]);
	/* һ�׵�ͨ�˲��õ����ٶ� */
	balance_infantry->theta_left_w = -balance_infantry->J_l[0][0] * balance_infantry->DM8009_Motor[1].para.vel - balance_infantry->J_l[1][0] * balance_infantry->DM8009_Motor[0].para.vel;
	balance_infantry->state_vector_l[0] = balance_infantry->theta_left;
	balance_infantry->state_vector_l[1] = -balance_infantry->theta_left_w ;

	/* �����Ȳ�thera�� */
	balance_infantry->theta_right = (PI/2 - balance_infantry->phi_right[0] - balance_infantry->state_vector_r[4]);
	//ͨ��vmc�������theta_dot
	balance_infantry->theta_right_w = balance_infantry->J_r[0][0] * balance_infantry->DM8009_Motor[2].para.vel + balance_infantry->J_r[1][0] * balance_infantry->DM8009_Motor[3].para.vel;
	balance_infantry->state_vector_r[0] = balance_infantry->theta_right;
	balance_infantry->state_vector_r[1] = -balance_infantry->theta_right_w ;
//	balance_infantry->state_vector_l[0] = - balance_infantry->state_vector_l[4];- balance_infantry->state_vector_l[5]
//	balance_infantry->state_vector_l[1] = 0;
//	balance_infantry->state_vector_r[0] = - balance_infantry->state_vector_l[4];- balance_infantry->state_vector_r[5]
//	balance_infantry->state_vector_r[1] = 0;
}

/**
 * @brief        Roll�����
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void roll_control(BalanceInfantry *balance_infantry)
{
	/* ���Ŵ�ȷ�� */
	float output;
	output = PID_calc(&balance_infantry->roll_control_pid, balance_infantry->Ins_Angle[2], balance_infantry->roll_set);
	if(balance_infantry->jump_flag == 0)
	{
		balance_infantry->extra_leg_force_l -= output;
		balance_infantry->extra_leg_force_r += output;
	}
}
/**
 * @brief        ������Ծ
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void jump(BalanceInfantry *balance_infantry)
{
	if(balance_infantry->jump_flag == 1)
	{
		const float leg_speed_pid_l[3] = {20,0,0};
		const float leg_speed_pid_r[3] = {20,0,0};
		PID_init(&balance_infantry->leg_speed_pid_l,PID_POSITION, leg_speed_pid_l, 15, 0);
		PID_init(&balance_infantry->leg_speed_pid_r,PID_POSITION, leg_speed_pid_r, 15, 0);
		if(balance_infantry->jump_status == 0)
		{
			balance_infantry->target_L_left = 0.1f;
			balance_infantry->target_L_right = 0.1f;
			if(balance_infantry->L_left[0] < 0.12f && balance_infantry->L_right[0] < 0.12f)
			{
				balance_infantry->jump_time++;
			}
			if(balance_infantry->jump_time >= 10)
			{
				balance_infantry->jump_status=1;
				balance_infantry->jump_time=0;
			}
		}
		else if(balance_infantry->jump_status == 1)
		{
			balance_infantry->target_L_left = 0.27f;
			balance_infantry->target_L_right = 0.27f;
			if(balance_infantry->L_left[0] > 0.24f && balance_infantry->L_right[0] > 0.24f)
			{
				balance_infantry->jump_time++;
			}
			if(balance_infantry->jump_time >= 10)
			{
				balance_infantry->jump_status=2;
				balance_infantry->jump_time=0;
			}
		}
		else if(balance_infantry->jump_status == 2)
		{
			balance_infantry->target_L_left = 0.14f;
			balance_infantry->target_L_right = 0.14f;
			if(balance_infantry->L_left[0] < 0.16f && balance_infantry->L_right[0] < 0.16f)
			{
				balance_infantry->jump_time++;
			}
			if(balance_infantry->jump_time >= 10)
			{
				balance_infantry->jump_status=3;
				balance_infantry->jump_time=0;
			}
		}
		if(balance_infantry->jump_status == 3)
		{
			const float leg_speed_pid_l[3] = {50,0,0};
			const float leg_speed_pid_r[3] = {50,0,0};
			PID_init(&balance_infantry->leg_speed_pid_l,PID_POSITION, leg_speed_pid_l, 15, 0);
			PID_init(&balance_infantry->leg_speed_pid_r,PID_POSITION, leg_speed_pid_r, 15, 0);
			balance_infantry->jump_time=0;
			balance_infantry->jump_status=0;
			balance_infantry->jump_flag=0;
		}
	}
}
/**
 * @brief        LQR����
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void LQR_Solve(BalanceInfantry *balance_infantry)
{
	float accel;
	for (uint8_t i = 0; i < 2; i++)
	{
		balance_infantry->virtual_torque_l[i] = 0;
		for (uint8_t j = 0; j < 6; j++)
		{
//			if(j == 3)
//			{
//				if(balance_infantry->target_vector[j] - balance_infantry->state_vector_l[j] > MAX_ACCEL)
//				{
//					accel = MAX_ACCEL;
//				}
//				else if(balance_infantry->target_vector[j] - balance_infantry->state_vector_l[j] < -MAX_ACCEL)
//				{
//					accel = -MAX_ACCEL;
//				}
//				else
//				{
//					accel = balance_infantry->target_vector[j] - balance_infantry->state_vector_l[j];
//				}
//				balance_infantry->virtual_torque_l[i] += balance_infantry->K_l[i][3] * accel;
//			}
//			if(j != 3)
//			{
				balance_infantry->virtual_torque_l[i] += balance_infantry->K_l[i][j] * (balance_infantry->target_vector[j] - balance_infantry->state_vector_l[j]);
//			}
		}
	}
	for (uint8_t i = 0; i < 2; i++)
	{
		balance_infantry->virtual_torque_r[i] = 0;
		for (uint8_t j = 0; j < 6; j++)
		{
//			if(j == 3)
//			{
//				if(balance_infantry->target_vector[j] - balance_infantry->state_vector_r[j] > MAX_ACCEL)
//				{
//					accel = MAX_ACCEL;
//				}
//				else if(balance_infantry->target_vector[j] - balance_infantry->state_vector_r[j] < -MAX_ACCEL)
//				{
//					accel = -MAX_ACCEL;
//				}
//				else
//				{
//					accel = balance_infantry->target_vector[j] - balance_infantry->state_vector_r[j];
//				}
//				balance_infantry->virtual_torque_r[i] += balance_infantry->K_r[i][3] * accel;
//			}
//			if(j != 3)
//			{
				balance_infantry->virtual_torque_r[i] += balance_infantry->K_r[i][j] * (balance_infantry->target_vector[j] - balance_infantry->state_vector_r[j]);
		
//			}

		}
	}
	if(balance_infantry->is_get_enough_force == FALSE)
	{
		balance_infantry->virtual_torque_l[0]=0;
		LeftSteerTorque=0;
		balance_infantry->virtual_torque_r[0]=0;
		RightSteerTorque=0;
		balance_infantry->virtual_torque_l[1]=balance_infantry->K_l[1][0] * (balance_infantry->target_vector[0] - balance_infantry->state_vector_l[0])+balance_infantry->K_l[1][1] * (balance_infantry->target_vector[1] - balance_infantry->state_vector_l[1]);
		balance_infantry->virtual_torque_r[1]=balance_infantry->K_r[1][0] * (balance_infantry->target_vector[0] - balance_infantry->state_vector_r[0])+balance_infantry->K_r[1][1] * (balance_infantry->target_vector[1] - balance_infantry->state_vector_r[1]);
	}
}

/**
 * @brief        VMC�����ȳ��ٶ�
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void get_leg_speed(BalanceInfantry *balance_infantry)
{
	/* ���� phi1��� phi4��С leg_speedΪ��ֵ */
	/* �����ٶ���� */
	float sigma, phi0_v;//leg_speed, 
	sigma = arm_sin_f32(balance_infantry->phi_left[2] - balance_infantry->phi_left[3]);
	phi0_v = balance_infantry->L_left[1] * arm_sin_f32(balance_infantry->phi_left[1] - balance_infantry->phi_left[2]) * arm_sin_f32(balance_infantry->phi_left[3]) / sigma * balance_infantry->DM8009_Motor[1].para.vel 
				+ balance_infantry->L_left[4] * arm_sin_f32(balance_infantry->phi_left[3] - balance_infantry->phi_left[4]) * arm_sin_f32(balance_infantry->phi_left[2]) / sigma * balance_infantry->DM8009_Motor[0].para.vel;
	balance_infantry->leg_speed_l = -balance_infantry->L_left[1] * arm_sin_f32(balance_infantry->phi_left[1] - balance_infantry->phi_left[2]) * arm_cos_f32(balance_infantry->phi_left[3]) / sigma * balance_infantry->DM8009_Motor[1].para.vel 
				- balance_infantry->L_left[4] * arm_sin_f32(balance_infantry->phi_left[3] - balance_infantry->phi_left[4]) * arm_cos_f32(balance_infantry->phi_left[2]) / sigma * balance_infantry->DM8009_Motor[0].para.vel;
	
	PID_calc(&balance_infantry->leg_speed_pid_l, balance_infantry->leg_speed_l, 0);
	balance_infantry->extra_leg_speed_force_l = balance_infantry->leg_speed_pid_l.out;
	
	/* �����ٶ���� */
	sigma = arm_sin_f32(balance_infantry->phi_right[2] - balance_infantry->phi_right[3]);
	phi0_v = -balance_infantry->L_right[1] * arm_sin_f32(balance_infantry->phi_right[1] - balance_infantry->phi_right[2]) * arm_sin_f32(balance_infantry->phi_right[3]) / sigma * balance_infantry->DM8009_Motor[2].para.vel 
				- balance_infantry->L_right[4] * arm_sin_f32(balance_infantry->phi_right[3] - balance_infantry->phi_right[4]) * arm_sin_f32(balance_infantry->phi_right[2]) / sigma * balance_infantry->DM8009_Motor[3].para.vel;
	balance_infantry->leg_speed_r = balance_infantry->L_right[1] * arm_sin_f32(balance_infantry->phi_right[1] - balance_infantry->phi_right[2]) * arm_cos_f32(balance_infantry->phi_right[3]) / sigma * balance_infantry->DM8009_Motor[2].para.vel 
				+ balance_infantry->L_right[4] * arm_sin_f32(balance_infantry->phi_right[3] - balance_infantry->phi_right[4]) * arm_cos_f32(balance_infantry->phi_right[2]) / sigma * balance_infantry->DM8009_Motor[3].para.vel;
	
	PID_calc(&balance_infantry->leg_speed_pid_r, balance_infantry->leg_speed_r, 0);
	balance_infantry->extra_leg_speed_force_r = balance_infantry->leg_speed_pid_r.out;

}
/**
 * @brief        VMC����
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void VMC_Solve(BalanceInfantry *balance_infantry)
{
	/* �������ȳ��ٶ� */
	balance_infantry->leg_speed_l = -balance_infantry->J_l[0][1] * balance_infantry->DM8009_Motor[1].para.vel - balance_infantry->J_l[1][1] * balance_infantry->DM8009_Motor[0].para.vel;
	PID_calc(&balance_infantry->leg_speed_pid_l, balance_infantry->leg_speed_l, 0);
	balance_infantry->extra_leg_speed_force_l = balance_infantry->leg_speed_pid_l.out;

	/* ��챵��������������������ص��޷� (���Ŵ�ȷ��) */
	balance_infantry->output_torque_l[0] = -balance_infantry->virtual_torque_l[0] - LeftSteerTorque;
	balance_infantry->virtual_torque_l[1] = LIMIT_MAX_MIN(-(balance_infantry->virtual_torque_l[1] + balance_infantry->extra_torque_l), MAX_VMC_TORQUE, MIN_VMC_TORQUE);
	balance_infantry->virtual_torque_l[2] = LIMIT_MAX_MIN(-( balance_infantry->extra_leg_speed_force_l+balance_infantry->extra_leg_force_l), MAX_VMC_FORCE, MIN_VMC_FORCE);
//	balance_infantry->virtual_torque_l[1] = balance_infantry->virtual_torque_l[1] / 1.5f;
//	balance_infantry->output_torque_l[0] = 0;//
//	balance_infantry->virtual_torque_l[1] = 0;
//	balance_infantry->virtual_torque_l[2] = 0;
	/* �ؽڵ��������������� */
	for (uint8_t i = 1; i < 3; i++)
	{
		balance_infantry->output_torque_l[i] = 0;
			for (uint8_t j = 0; j < 2; j++)
			{
				balance_infantry->output_torque_l[i] += balance_infantry->J_l[i - 1][j] * balance_infantry->virtual_torque_l[j + 1];
			}
	}

	/* ???VMC?? */

	/* �������ȳ��ٶ� */
	balance_infantry->leg_speed_r = balance_infantry->J_r[0][1] * balance_infantry->DM8009_Motor[2].para.vel + balance_infantry->J_r[1][1] * balance_infantry->DM8009_Motor[3].para.vel;
	PID_calc(&balance_infantry->leg_speed_pid_r, balance_infantry->leg_speed_r, 0);
	balance_infantry->extra_leg_speed_force_r = balance_infantry->leg_speed_pid_r.out;

	/* ��챵��������������������ص��޷� (���Ŵ�ȷ��) */
	balance_infantry->output_torque_r[0] = -balance_infantry->virtual_torque_r[0] + RightSteerTorque;
	balance_infantry->virtual_torque_r[1] = LIMIT_MAX_MIN(-(balance_infantry->virtual_torque_r[1] + balance_infantry->extra_torque_r), MAX_VMC_TORQUE, MIN_VMC_TORQUE);
	balance_infantry->virtual_torque_r[2] = LIMIT_MAX_MIN(-(balance_infantry->extra_leg_speed_force_r+balance_infantry->extra_leg_force_r), MAX_VMC_FORCE, MIN_VMC_FORCE);
//	balance_infantry->virtual_torque_r[1] = balance_infantry->virtual_torque_r[1] / 1.5f;
//	balance_infantry->output_torque_r[0] = 0;//
//	balance_infantry->virtual_torque_r[1] = 0;
//	balance_infantry->virtual_torque_r[2] = 0;// 
	/* �ؽڵ��������������� */
	for (uint8_t i = 1; i < 3; i++)
	{
		balance_infantry->output_torque_r[i] = 0;
			for (uint8_t j = 0; j < 2; j++)
			{
				balance_infantry->output_torque_r[i] += balance_infantry->J_r[i - 1][j] * balance_infantry->virtual_torque_r[j + 1];
			}
	}
//	balance_infantry->output_torque_r[1] = balance_infantry->J_r[0][0] * balance_infantry->virtual_torque_r[1] + balance_infantry->J_r[0][1] * balance_infantry->virtual_torque_r[2];
//	balance_infantry->output_torque_r[2] = balance_infantry->J_r[1][0] * balance_infantry->virtual_torque_r[1] + balance_infantry->J_r[1][1] * balance_infantry->virtual_torque_r[2];
//	balance_infantry->output_torque_r[1] = balance_infantry->J_r[1][0] * balance_infantry->virtual_torque_r[1] + balance_infantry->J_r[1][1] * balance_infantry->virtual_torque_r[2];
//	balance_infantry->output_torque_r[2] = balance_infantry->J_r[0][0] * balance_infantry->virtual_torque_r[1] + balance_infantry->J_r[0][1] * balance_infantry->virtual_torque_r[2];
	
}
/**
 * @brief        ʵʱ�����������K
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void updataK(BalanceInfantry *balance_infantry)
{
	/* ����K */
	float pow2 = balance_infantry->L_left[0] * balance_infantry->L_left[0];
	float pow3 = balance_infantry->L_left[0] * balance_infantry->L_left[0] * balance_infantry->L_left[0];
	for (uint8_t i = 0; i < 2; i++)
	{
		for (uint8_t j = 0; j < 6; j++)
		{
			balance_infantry->K_l[i][j] =
				balance_infantry->K_coef[i * 6 + j][3] + balance_infantry->K_coef[i * 6 + j][2] * balance_infantry->L_left[0] + balance_infantry->K_coef[i * 6 + j][1] * pow2 + balance_infantry->K_coef[i * 6 + j][0] * pow3;
		}
	}

	/* ����K */
	pow2 = balance_infantry->L_right[0] * balance_infantry->L_right[0];
	pow3 = balance_infantry->L_right[0] * balance_infantry->L_right[0] * balance_infantry->L_right[0];
	for (uint8_t i = 0; i < 2; i++)
	{
		for (uint8_t j = 0; j < 6; j++)
		{
			balance_infantry->K_r[i][j] =
				balance_infantry->K_coef[i * 6 + j][3] + balance_infantry->K_coef[i * 6 + j][2] * balance_infantry->L_right[0] + balance_infantry->K_coef[i * 6 + j][1] * pow2 + balance_infantry->K_coef[i * 6 + j][0] * pow3;
		}
	}
}

/**
 * @brief  ���ο���
 * @param  �������趨�����ٶ�
 * @retval ���ֵ
 */
float ramp_control(float ref, float set, float accel)
{
    float ramp = LIMIT_MAX_MIN(accel, 1, 0) * (set - ref);
    return ref + ramp;
}

/**
 * @brief        �ȳ�����
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void leg_control(BalanceInfantry *balance_infantry)
{
//	ramp_control(balance_infantry->L_left[0], balance_infantry->target_L_left, 
//	if (Lqr->LqrData.TargetDis - Lqr->LqrData.Dis > 0.15f)
//    {
//        Lqr->LqrData.TargetDis = Lqr->LqrData.Dis + 0.15f;
//    }
//    else if (Lqr->LqrData.TargetDis - Lqr->LqrData.Dis < -0.15f)
//    {
//        Lqr->LqrData.TargetDis = Lqr->LqrData.Dis - 0.15f;
//    }
//	float target_left,target_right;
//	if(balance_infantry->target_L_left - balance_infantry->L_left[0] > 0.03f)
//	{
//		target_left = balance_infantry->L_left[0] + 0.03f;
//	}
//	else if (balance_infantry->target_L_left - balance_infantry->L_left[0] < -0.03f)
//	{
//		target_left = balance_infantry->L_left[0] - 0.03f;
//	}
//	else
//	{
//		target_left = balance_infantry->target_L_left;
//	}
//	
//	if(balance_infantry->target_L_right - balance_infantry->L_right[0] > 0.03f)
//	{
//		target_right = balance_infantry->L_right[0] + 0.03f;
//	}
//	else if (balance_infantry->target_L_right - balance_infantry->L_right[0] < -0.03f)
//	{
//		target_right = balance_infantry->L_right[0] - 0.03f;
//	}
//	else
//	{
//		target_right = balance_infantry->target_L_right;
//	}
	if(balance_infantry->jump_flag == 0)
	{
		balance_infantry->target_L_left = 0.14f+balance_infantry->ChassisRC->rc.ch[3] * 0.00015454545f;
		balance_infantry->target_L_right = 0.14f+balance_infantry->ChassisRC->rc.ch[3] * 0.00015454545f;
		LIMIT_MAX_MIN(balance_infantry->target_L_left,0.24f,0.12f);
		LIMIT_MAX_MIN(balance_infantry->target_L_right,0.24f,0.12f);
	}
	/* �ȳ�����pid���� (���Ŵ�ȷ��)+  */
	balance_infantry->extra_leg_force_l = PID_calc(&balance_infantry->leg_control_pid_l, balance_infantry->L_left[0], balance_infantry->target_L_left)+12.0f;//
	balance_infantry->extra_leg_force_r = PID_calc(&balance_infantry->leg_control_pid_r, balance_infantry->L_right[0], balance_infantry->target_L_right) + 12.0f;//
}

/**
 * @brief        ��ؼ��
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void off_ground_detect(BalanceInfantry *balance_infantry)
{
	/* ����ʱ���������ȵ����ȷ�� */
	float J_inv[2][2];
	float coef = balance_infantry->J_l[0][0] * balance_infantry->J_l[1][1] - balance_infantry->J_l[0][1] * balance_infantry->J_l[1][0];
	J_inv[0][0] = balance_infantry->J_l[1][1] / coef;
	J_inv[0][1] = -balance_infantry->J_l[0][1] / coef;
	J_inv[1][0] = -balance_infantry->J_l[1][0] / coef;
	J_inv[1][1] = balance_infantry->J_l[0][0] / coef;

	balance_infantry->wheel_f_torque_feedback_l[0] =
		J_inv[0][0] * balance_infantry->DM8009_Motor[LEFT_KNEE_LEFT].para.tor + J_inv[0][1] * balance_infantry->DM8009_Motor[LEFT_KNEE_RIGHT].para.tor;
	balance_infantry->wheel_f_torque_feedback_l[1] =
		J_inv[1][0] * balance_infantry->DM8009_Motor[LEFT_KNEE_LEFT].para.tor + J_inv[1][1] * balance_infantry->DM8009_Motor[LEFT_KNEE_RIGHT].para.tor;

	/* ����ʱ���������ȵ����ȷ�� */
	/* ������� */
	coef = balance_infantry->J_r[0][0] * balance_infantry->J_r[1][1] - balance_infantry->J_r[0][1] * balance_infantry->J_r[1][0];
	J_inv[0][0] = balance_infantry->J_r[1][1] / coef;
	J_inv[0][1] = -balance_infantry->J_r[0][1] / coef;
	J_inv[1][0] = -balance_infantry->J_r[1][0] / coef;
	J_inv[1][1] = balance_infantry->J_r[0][0] / coef;

	balance_infantry->wheel_f_torque_feedback_r[0] =
		J_inv[0][0] * balance_infantry->DM8009_Motor[RIGHT_KNEE_RIGHT].para.tor + J_inv[0][1] * balance_infantry->DM8009_Motor[RIGHT_KNEE_LEFT].para.tor;
	balance_infantry->wheel_f_torque_feedback_r[1] =
		J_inv[1][0] * balance_infantry->DM8009_Motor[RIGHT_KNEE_RIGHT].para.tor + J_inv[1][1] * balance_infantry->DM8009_Motor[RIGHT_KNEE_LEFT].para.tor;

	float L_l = balance_infantry->L_left[0] * arm_cos_f32(balance_infantry->theta_left);
	float L_r = balance_infantry->L_right[0] * arm_cos_f32(balance_infantry->theta_right);

	/* �ٶȹ��� */
	rc_filter(&balance_infantry->L_theta_v_l, (L_l - balance_infantry->last_l_theta_l) / 0.002f, 0.002f, LP_THETA_V_RC);
	rc_filter(&balance_infantry->L_theta_v_r, (L_r - balance_infantry->last_l_theta_r) / 0.002f, 0.002f, LP_THETA_V_RC);
	balance_infantry->last_l_theta_l = L_l;
	balance_infantry->last_l_theta_r = L_r;

	/* ���ٶȹ��� */
	rc_filter(&balance_infantry->L_theta_a_l, (balance_infantry->L_theta_v_l - balance_infantry->last_l_theta_v_l) / 0.002f, 0.002f, 0.0018);
	rc_filter(&balance_infantry->L_theta_a_r, (balance_infantry->L_theta_v_r - balance_infantry->last_l_theta_v_r) / 0.002f, 0.002f, 0.0018);
	balance_infantry->last_l_theta_v_l = balance_infantry->L_theta_v_l;
	balance_infantry->last_l_theta_v_r = balance_infantry->L_theta_v_r;

	/* �Ȳ������һ�׵�ͨ�˲�(�����������ٶ�) */
	balance_infantry->FN_l = 
		-(balance_infantry->extra_leg_speed_force_l+balance_infantry->extra_leg_force_l) * arm_cos_f32(balance_infantry->theta_left) -
		(balance_infantry->virtual_torque_l[1] + balance_infantry->extra_torque_l) * arm_sin_f32(balance_infantry->theta_left)/ balance_infantry->L_left[0] + WHEEL_WEIGHT;
	balance_infantry->FN_r = 
		-(balance_infantry->extra_leg_speed_force_r+balance_infantry->extra_leg_force_r) * arm_cos_f32(balance_infantry->theta_right) -
		(balance_infantry->virtual_torque_r[1] + balance_infantry->extra_torque_r) * arm_sin_f32(balance_infantry->theta_right)/ balance_infantry->L_right[0] + WHEEL_WEIGHT;
	
//	balance_infantry->FN_l =
//		balance_infantry->wheel_f_torque_feedback_l[1] * arm_cos_f32(balance_infantry->theta_left) -
//		balance_infantry->wheel_f_torque_feedback_l[0] * arm_cos_f32(balance_infantry->theta_left) / balance_infantry->L_left[0] +
//		WHEEL_WEIGHT * (GRAVITY - balance_infantry->L_theta_a_l);
//	balance_infantry->FN_r =
//		-balance_infantry->wheel_f_torque_feedback_r[1] * arm_cos_f32(balance_infantry->theta_right) +
//		balance_infantry->wheel_f_torque_feedback_r[0] * arm_cos_f32(balance_infantry->theta_right) / balance_infantry->L_right[0] +
//		WHEEL_WEIGHT * (GRAVITY - balance_infantry->L_theta_a_r);
	/* �����ɼ����ͨ�˲� */
	if (balance_infantry->FN_l > 13 && balance_infantry->FN_r > 13)
	{
		balance_infantry->is_get_enough_force = FALSE;
	}
	else if (balance_infantry->FN_l < 12 && balance_infantry->FN_r < 12)
	{
		balance_infantry->is_get_enough_force = TRUE;
	}
}

/**
 * @brief        �������˲��ں�
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
float vel;
void accel_odom_fusion(BalanceInfantry *balance_infantry)
{
    balance_infantry->Wheel_Accel_Fusion->Q1 = 10;//0.0005 * 10
    balance_infantry->Wheel_Accel_Fusion->Q2 = 30;
    balance_infantry->Wheel_Accel_Fusion->R1 = 200;

	/* ���Ŵ�ȷ�� accel�����ֵ��ȷ�� */
	vel = balance_infantry->state_vector_l[3];
    KF_Wheel_Accel_Update(vel,
                          balance_infantry->Motion_Accel[0], 0.002f);

//	KF_Wheel_Accel_Update(balance_infantry->state_vector_r[3],
//                          balance_infantry->AccelData[0], 0.002f);
}
/**
 * @brief        �������
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void motor_output(BalanceInfantry *balance_infantry)
{
	/* ���ȵ����� */
	balance_infantry->output_current_l = balance_infantry->output_torque_l[0] * MF9025TORQUEPROPORTION;
	
	balance_infantry->output_current_r = balance_infantry->output_torque_r[0] * MF9025TORQUEPROPORTION;
	LIMIT_MAX_MIN(balance_infantry->output_current_l,1500,-1500);
	LIMIT_MAX_MIN(balance_infantry->output_current_r,1500,-1500);

//	rc_filter(&balance_infantry->output_current_l,balance_infantry->output_torque_l[0] * MF9025TORQUEPROPORTION,0.002f,0.0015f);
//	rc_filter(&balance_infantry->output_current_r,balance_infantry->output_torque_r[0] * MF9025TORQUEPROPORTION,0.002f,0.0015f);
//	MF9025DataSet(LeftMotor,balance_infantry->output_current_l);
//	MF9025DataSet(RightMotor,balance_infantry->output_current_r);
}
/**
 * @brief        �������
 * @param    	  BalanceInfantry�ṹ��
 * @retval 	  none
 */
void main_control(BalanceInfantry *balance_infantry)
{
	get_sensor_message(balance_infantry);

	set_target_vector(balance_infantry);
	MotionSolve(balance_infantry);
	getTheta(balance_infantry);

	/* ���ؼ��� */
	updataK(balance_infantry);
	LQR_Solve(balance_infantry);

	leg_control(balance_infantry);

	VMC_Solve(balance_infantry);

	off_ground_detect(balance_infantry);

	/* ������� */
	motor_output(balance_infantry);

	/* �޷� */
}
