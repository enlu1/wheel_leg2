/**
  ****************************(C) COPYRIGHT 2024 Ultra****************************
  * @file       dm8009_task.c/h
  * @brief      no action.
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     04-22-2024     Zhang Enlu         1. done
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2024 Ultra****************************
  */
#ifndef DM8009_TASK_H
#define DM8009_TASK_H
#include "struct_typedef.h"
#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "Chassis_task.h"
#include "dm4310_drv.h"
#include "bsp_can.h"
#include "struct_typedef.h"
#include "ChassisControl.h"

void dm8009_task(void const *pvParameters);

#endif
