#include "usart.h"

#include "main.h"

void Quaternion_parsing(uint8_t *Rxbuff, float *INS_q);
void WT901cDataReceive(void);
