#include "wt901c.h"

uint8_t RxBuff[11];
float INS_q[4];
void Quaternion_parsing(uint8_t *Rxbuff, float *INS_q);
void WT901cDataReceive(void)
{
	HAL_UART_Receive_IT(&huart1, RxBuff, 11);
		if(RxBuff[0] == 0x55)
		{
			switch(RxBuff[1])
			{
				case 0x59:
					Quaternion_parsing(RxBuff,INS_q);
					break;
			}
			
		}
	
	
}

void Quaternion_parsing(uint8_t *Rxbuff, float *INS_q)
{
	INS_q[0] = ((Rxbuff[3]<<8)|RxBuff[2])/32768.0f;
	INS_q[1] = ((Rxbuff[5]<<8)|RxBuff[4])/32768.0f;
	INS_q[2] = ((Rxbuff[7]<<8)|RxBuff[6])/32768.0f;
	INS_q[3] = ((Rxbuff[9]<<8)|RxBuff[8])/32768.0f;
}
