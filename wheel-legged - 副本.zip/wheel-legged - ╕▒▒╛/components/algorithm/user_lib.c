#include "user_lib.h"


/**
  * @brief          б��������ʼ��
  * @author         RM
  * @param[in]      б�������ṹ��
  * @param[in]      �����ʱ�䣬��λ s
  * @param[in]      ���ֵ
  * @param[in]      ��Сֵ
  * @retval         ���ؿ�
  */
void ramp_init(ramp_function_source_t *ramp_source_type, fp32 frame_period, fp32 max, fp32 min)
{
    ramp_source_type->frame_period = frame_period;
    ramp_source_type->max_value = max;
    ramp_source_type->min_value = min;
    ramp_source_type->input = 0.0f;
    ramp_source_type->out = 0.0f;
}

/**
  * @brief          б���������㣬���������ֵ���е��ӣ� ���뵥λΪ /s ��һ������������ֵ
  * @author         RM
  * @param[in]      б�������ṹ��
  * @param[in]      ����ֵ
  * @param[in]      �˲�����
  * @retval         ���ؿ�
  */
void ramp_calc(ramp_function_source_t *ramp_source_type, fp32 input)
{
    ramp_source_type->input = input;
    ramp_source_type->out += ramp_source_type->input * ramp_source_type->frame_period;
    if (ramp_source_type->out > ramp_source_type->max_value)
    {
        ramp_source_type->out = ramp_source_type->max_value;
    }
    else if (ramp_source_type->out < ramp_source_type->min_value)
    {
        ramp_source_type->out = ramp_source_type->min_value;
    }
}
/**
  * @brief          һ�׵�ͨ�˲���ʼ��
  * @author         RM
  * @param[in]      һ�׵�ͨ�˲��ṹ��
  * @param[in]      �����ʱ�䣬��λ s
  * @param[in]      �˲�����
  * @retval         ���ؿ�
  */
void first_order_filter_init(first_order_filter_type_t *first_order_filter_type, fp32 frame_period, const fp32 num[1])
{
    first_order_filter_type->frame_period = frame_period;
    first_order_filter_type->num[0] = num[0];
    first_order_filter_type->input = 0.0f;
    first_order_filter_type->out = 0.0f;
}

/**
  * @brief          һ�׵�ͨ�˲�����
  * @author         RM
  * @param[in]      һ�׵�ͨ�˲��ṹ��
  * @param[in]      �����ʱ�䣬��λ s
  * @retval         ���ؿ�
  */
void first_order_filter_cali(first_order_filter_type_t *first_order_filter_type, fp32 input)
{
    first_order_filter_type->input = input;
    first_order_filter_type->out =
        first_order_filter_type->num[0] / (first_order_filter_type->num[0] + first_order_filter_type->frame_period) * first_order_filter_type->out + first_order_filter_type->frame_period / (first_order_filter_type->num[0] + first_order_filter_type->frame_period) * first_order_filter_type->input;
}

//��������
void abs_limit(fp32 *num, fp32 Limit)
{
    if (*num > Limit)
    {
        *num = Limit;
    }
    else if (*num < -Limit)
    {
        *num = -Limit;
    }
}

//�жϷ���λ
fp32 sign(fp32 value)
{
    if (value >= 0.0f)
    {
        return 1.0f;
    }
    else
    {
        return -1.0f;
    }
}

//��������
fp32 fp32_deadline(fp32 Value, fp32 minValue, fp32 maxValue)
{
    if (Value < maxValue && Value > minValue)
    {
        Value = 0.0f;
    }
    return Value;
}

//int26����
int16_t int16_deadline(int16_t Value, int16_t minValue, int16_t maxValue)
{
    if (Value < maxValue && Value > minValue)
    {
        Value = 0;
    }
    return Value;
}

//�޷�����
fp32 fp32_constrain(fp32 Value, fp32 minValue, fp32 maxValue)
{
    if (Value < minValue)
        return minValue;
    else if (Value > maxValue)
        return maxValue;
    else
        return Value;
}

//�޷�����
int16_t int16_constrain(int16_t Value, int16_t minValue, int16_t maxValue)
{
    if (Value < minValue)
        return minValue;
    else if (Value > maxValue)
        return maxValue;
    else
        return Value;
}

//ѭ���޷�����
fp32 loop_fp32_constrain(fp32 Input, fp32 minValue, fp32 maxValue)
{
    if (maxValue < minValue)
    {
        return Input;
    }

    if (Input > maxValue)
    {
        fp32 len = maxValue - minValue;
        while (Input > maxValue)
        {
            Input -= len;
        }
    }
    else if (Input < minValue)
    {
        fp32 len = maxValue - minValue;
        while (Input < minValue)
        {
            Input += len;
        }
    }
    return Input;
}

//���ȸ�ʽ��Ϊ-PI~PI

//�Ƕȸ�ʽ��Ϊ-180~180
fp32 theta_format(fp32 Ang)
{
    return loop_fp32_constrain(Ang, -180.0f, 180.0f);
}

static const float atan2_coefs_f32[ATAN2_NB_COEFS_F32] = {0.0f, 1.0000001638308195518f, -0.0000228941363602264f, -0.3328086544578890873f, -0.004404814619311061f, 0.2162217461808173258f, -0.0207504842057097504f, -0.1745263362250363339f, 0.1340557235283553386f, -0.0323664125927477625f};

float arm_atan_limited_f32(float x)
{
  float res = atan2_coefs_f32[ATAN2_NB_COEFS_F32 - 1];
  int i = 1;
  for (i = 1; i < ATAN2_NB_COEFS_F32; i++)
  {
    res = x * res + atan2_coefs_f32[ATAN2_NB_COEFS_F32 - 1 - i];
  }

  return (res);
}

float arm_atan_f32(float x)
{
  int sign = 0;
  float res = 0.0f;

  if (x < 0.0f)
  {
    sign = 1;
    x = -x;
  }

  if (x > 1.0f)
  {
    x = 1.0f / x;
    res = PIHALFF32 - arm_atan_limited_f32(x);
  }
  else
  {
    res += arm_atan_limited_f32(x);
  }

  if (sign)
  {
    res = -res;
  }

  return (res);
}

/**
  @ingroup groupFastMath
 */

/**
  @defgroup atan2 ArcTan2

  Computing Arc tangent only using the ratio y/x is not enough to determine the angle
  since there is an indeterminacy. Opposite quadrants are giving the same ratio.

  ArcTan2 is not using y/x to compute the angle but y and x and use the sign of y and x
  to determine the quadrant.

 */

/**
  @addtogroup atan2
  @{
 */

/**
  @brief       Arc Tangent of y/x using sign of y and x to get right quadrant
  @param[in]   y  y coordinate
  @param[in]   x  x coordinate
  @param[out]  result  Result
  @return  error status.

  @par         Compute the Arc tangent of y/x:
                   The sign of y and x are used to determine the right quadrant
                   and compute the right angle.
*/

float arm_atan2_f32(float y, float x)
{
  if (x > 0.0f)
  {
    return arm_atan_f32(y / x);
  }
  if (x < 0.0f)
  {
    if (y > 0.0f)
    {
      return arm_atan_f32(y / x) + PI;
    }
    else
    {
      return arm_atan_f32(y / x) - PI;
    }
  }
  if (x == 0.0f)
  {
    if (y > 0.0f)
    {
      return PIHALFF32;
    }
    if (y < 0.0f)
    {
      return -PIHALFF32;
    }
  }
  return 0.0f;
}

/* һ�׵�ͨ�˲��� */
void rc_filter(float *raw_data, float new_data, float delta_t, float LPF_RC)
{
    *raw_data = new_data * delta_t / (LPF_RC + delta_t) +
                *raw_data * LPF_RC / (LPF_RC + delta_t);
}
/* �¶ȸ��� */
void slope_following(float *target,float *set,float acc)
{
	if(*target > *set)
	{
		*set = *set + acc;
		if(*set >= *target)
		*set = *target;
	}
	else if(*target < *set)
	{
		*set = *set - acc;
		if(*set <= *target)
		*set = *target;
	}

}

